
"""
Esta clase se responsabiliza de ....
"""
class congelador:
    
    def __init__(self) -> None:
        pass

    def congelar(self):
        pass