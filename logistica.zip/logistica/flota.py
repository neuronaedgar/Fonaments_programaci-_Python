"""
Esta clase se responsabiliza de ....
"""
class flota:
    
    def __init__(self) -> None:
        self.__camiones = list()

    def add(self, camion):
        self.__camiones.append(camion)

    def llenar_camiones(self, items):
        for camion in self.__camiones:
            for pos, item in enumerate(items):
                camion.cargar(pos, item)

    def vaciar_camiones(self, items):
        pass


    def __getitem__(self, index):
        return self.__camiones[index]

    def __setitem__(self, index, camion):
        """Metodo que sirve para modificar, no crear"""
        self.__camiones[index] = camion
    