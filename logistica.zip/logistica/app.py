"""
Programa principal de logistoca que usa las entidades....
"""

from flota import flota
from camion_electrico import camion_electrico
from contenedor_congelador import contenedor_congelador
from camion_motor import camion_motor

from collections import namedtuple

if __name__ == "__main__":
    flota = flota()

    flota.add(camion_motor(10))
    #flota.add(camion_electrico(5))

    mercancia = [contenedor_congelador(5),contenedor_congelador(5)]
    flota.llenar_camiones(mercancia)

    orden_trabajo = namedtuple("orden_trabajo", ['origen', 'destino','cliente'])

    orden = orden_trabajo(origen='Alemania',destino='Espanya',cliente='Zara')

    print(orden.cliente)

    #flota.iniciar_marcha()


    
    

    