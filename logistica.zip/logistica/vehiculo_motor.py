from vehiculo import vehiculo

class vehiculo_motor(vehiculo):
    
    def __init__(self) -> None:
        super().__init__()

    def arrancar(self):
        pass
