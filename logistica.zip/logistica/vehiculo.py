class vehiculo:
    
    def __init__(self) -> None:
        self.__origen = None
        self.__destino = None

    #comportamiento
    def desplazar(self):
        pass

    def acelerar(self):
        pass

    def desacelerar():
        pass
    
    