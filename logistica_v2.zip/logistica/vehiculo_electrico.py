from vehiculo import vehiculo

class vehiculo_electrico(vehiculo):
    
    def __init__(self) -> None:
        super().__init__()

    def cargar_bateria(self):
        pass
